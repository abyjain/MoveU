package com.polidea.rxandroidble.internal.connection;


interface MtuProvider {

    int getMtu();
}
