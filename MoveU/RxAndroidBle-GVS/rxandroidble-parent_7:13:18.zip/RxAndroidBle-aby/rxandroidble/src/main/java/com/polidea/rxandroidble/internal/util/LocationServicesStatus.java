package com.polidea.rxandroidble.internal.util;


public interface LocationServicesStatus {

    boolean isLocationPermissionOk();
    boolean isLocationProviderOk();
}
